public class Contact {
	//This set of variables gives the list of traits that our contact will have
	private String uniqueID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	//This constructor takes each variable from outside of the class and sets each local variable using the given methods
	public Contact(String ID,String firstName,String lastName,String phone,String address){
		if(ID.length() <= 10 && ID != null) {
			this.uniqueID = ID;
		}
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setPhoneNumber(phone);
		this.setAddress(address);
	}

	//This sets the first name by ensuring that the entered first name is not null and is less than or equal to 10 in length
	public void setFirstName(String firstName) {
		if(firstName.length() <= 10 && firstName != null) {
			this.firstName = firstName;
		}
	}
	//This sets the last name by ensuring that the entered last name is not null and is less than or equal to 10 in length
	public void setLastName(String lastName) {
		if(lastName.length() <= 10 && lastName != null) {
			this.lastName = lastName;
		}
	}
	//This sets the phone number by ensuring that the number is exactly 10 digits in length
	public void setPhoneNumber(String phoneNumber) {
		if(phoneNumber.length() == 10 && phoneNumber != null) {
			this.phoneNumber = phoneNumber;
		}
	}
	//This sets the address by ensuring that the address entered is less than 30 in length
	public void setAddress(String address) {
		if(address.length() <= 30 && address != null) {
			this.address = address;
		}
	}
	//These are simply the return methods for each variable
	public String getUniqueID() {
		return uniqueID;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getAddress() {
		return address;
	}
}