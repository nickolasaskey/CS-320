import org.junit.Assert;
import org.junit.Test;

public class ContactServiceTest {
	private ContactService contactService = new ContactService();
	
	@Test
	public void testAdd() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH 03264";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		
		contactService.addContact(contact);
		
		Assert.assertEquals(1, contactService.getContacts().size());
		Assert.assertEquals(contact, contactService.getContacts().get(0));
	}
	
	@Test
	public void testDelete() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH 03264";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		contactService.addContact(contact);
		
		Assert.assertEquals(1, contactService.getContacts().size());
		contactService.deleteContact(uniqueID);
		Assert.assertEquals(0, contactService.getContacts().size());
	}
	
	@Test
	public void testUpdateFirst() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH 03264";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		contactService.addContact(contact);
		
		String newFirst = "James";
		
		contactService.updateContactFirstName(uniqueID, newFirst);
		
		Assert.assertEquals(contactService.getContacts().get(0).getFirstName(), newFirst);
	}
	
	@Test
	public void testUpdateLast() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH 03264";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		contactService.addContact(contact);
		
		String newLast = "Snyder";
		
		contactService.updateContactLastName(uniqueID, newLast);
		
		Assert.assertEquals(contactService.getContacts().get(0).getLastName(), newLast);
	}
	
	@Test
	public void testUpdateNumber() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH 03264";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		contactService.addContact(contact);
		
		String newNumber = "6034212244";
		
		contactService.updateContactNumber(uniqueID, newNumber);
		
		Assert.assertEquals(contactService.getContacts().get(0).getPhoneNumber(), newNumber);
	}
	
	@Test
	public void testUpdateAddress() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH 03264";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		contactService.addContact(contact);
		
		String newAddress = "72 Int St. Plymouth, NH 03264";
		
		contactService.updateContactAddress(uniqueID, newAddress);
		
		Assert.assertEquals(contactService.getContacts().get(0).getAddress(), newAddress);
	}
}