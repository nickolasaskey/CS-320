import java.util.ArrayList;
import java.util.List;

//First we must make an arraylist of contacts using the Contact class we created
public class ContactService {
	ArrayList<Contact> contacts;

	public ContactService() {
		contacts = new ArrayList<>();
	}

	//To ensure that we CAN add a contact to the list, we must test each contact in the contact list
	//to the added contact, if any have the same ID, break from the list and return false
	public boolean addContact(Contact newContact) {
		boolean has = false;
		for (Contact c : contacts) {
			if (c.getUniqueID().equalsIgnoreCase(newContact.getUniqueID())) {
				has = true;
				break;
			}
		}
		//Otherwise, if there are no matching IDs, then add a new contact using the entered information
		if (!has) {
			contacts.add(newContact);
			return true;
		} else {
			return false;
		}
	}

	//Similarly to the add contact, for delete contact we check each entry in the contact list and
	//compare their IDs to the contact ID we want to delete.  If there is a match, then remove the matching
	//contact.  Otherwise, return false.
	public boolean deleteContact(String uniqueID) {
		boolean deleted = false;
		for (Contact c : contacts) {
			if (c.getUniqueID().equalsIgnoreCase(uniqueID)) {
				contacts.remove(c);
				deleted = true;
				break;
			}
		}
		return deleted;
	}

	// Compare the contact ID entered to every contact ID in the list, if there is a match then change
	// that contacts firstName variable.
	public boolean updateContactFirstName(String uniqueID, String newFirstName) {
		boolean updateFirst = false;
		for (Contact c : contacts) {
			if (c.getUniqueID().equalsIgnoreCase(uniqueID)) {
				c.setFirstName(newFirstName);
				updateFirst = true;
				break;
			}
		}
		return updateFirst;
	}

	// Compare the contact ID entered to every contact ID in the list, if there is a match then change
	// that contacts lastName variable.
	public boolean updateContactLastName(String uniqueID, String newLastName) {
		boolean updateLast = false;
		for (Contact c : contacts) {
			if (c.getUniqueID().equalsIgnoreCase(uniqueID)) {
				c.setLastName(newLastName);
				updateLast = true;
				break;
			}
		}
		return updateLast;
	}

	// Compare the contact ID entered to every contact ID in the list, if there is a match then change
	// that contacts number variable.
	public boolean updateContactNumber(String uniqueID, String newNumber) {
		boolean updateNumber = false;
		for (Contact c : contacts) {
			if (c.getUniqueID().equalsIgnoreCase(uniqueID)) {
				c.setPhoneNumber(newNumber);
				updateNumber = true;
				break;
			}
		}
		return updateNumber;
	}

	// Compare the contact ID entered to every contact ID in the list, if there is a match then change
	// that contacts address variable.
	public boolean updateContactAddress(String uniqueID, String newAddress) {
		boolean updateAddress = false;
		for (Contact c : contacts) {
			if (c.getUniqueID().equalsIgnoreCase(uniqueID)) {
				c.setAddress(newAddress);
				updateAddress = true;
				break;
			}
		}
		return updateAddress;
	}
	public List<Contact> getContacts() {
		return contacts;
	}
	

}