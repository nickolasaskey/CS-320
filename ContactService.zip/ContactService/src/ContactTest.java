import org.junit.Assert;
import org.junit.Test;

public class ContactTest {
	private ContactService contactService = new ContactService();
	
	@Test
	public void testContact() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		
		contactService.addContact(contact);
		
		Assert.assertEquals(uniqueID, contact.getUniqueID());
		Assert.assertEquals(firstName, contact.getFirstName());
		Assert.assertEquals(lastName, contact.getLastName());
		Assert.assertEquals(phoneNumber, contact.getPhoneNumber());
		Assert.assertEquals(address, contact.getAddress());
	}
	@Test
	public void testUniqueIDLength() {
		String uniqueID = "AF124ubUDB24ub2u4bfgu1b";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		
		contactService.addContact(contact);
		
		//The ID should reject using the JUnit test
		Assert.assertEquals(uniqueID, contact.getUniqueID());
		Assert.assertEquals(firstName, contact.getFirstName());
		Assert.assertEquals(lastName, contact.getLastName());
		Assert.assertEquals(phoneNumber, contact.getPhoneNumber());
		Assert.assertEquals(address, contact.getAddress());
	}
	@Test
	public void testFirstNameLength() {
		String uniqueID = "BB1234";
		String firstName = "Nickajaquiah";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		
		contactService.addContact(contact);
		
		Assert.assertEquals(uniqueID, contact.getUniqueID());
		//The first name should reject using the JUnit test
		Assert.assertEquals(firstName, contact.getFirstName());
		Assert.assertEquals(lastName, contact.getLastName());
		Assert.assertEquals(phoneNumber, contact.getPhoneNumber());
		Assert.assertEquals(address, contact.getAddress());
	}
	@Test
	public void testLastNameLength() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askeyliscious";
		String phoneNumber = "8145055055";
		String address = "14 String St. Plymouth, NH";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		
		contactService.addContact(contact);
		
		Assert.assertEquals(uniqueID, contact.getUniqueID());
		Assert.assertEquals(firstName, contact.getFirstName());
		//The last name should reject using the JUnit test
		Assert.assertEquals(lastName, contact.getLastName());
		Assert.assertEquals(phoneNumber, contact.getPhoneNumber());
		Assert.assertEquals(address, contact.getAddress());
	}
	@Test
	public void testPhoneNumberLength() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "828";
		String address = "14 String St. Plymouth, NH";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		
		contactService.addContact(contact);
		
		Assert.assertEquals(uniqueID, contact.getUniqueID());
		Assert.assertEquals(firstName, contact.getFirstName());
		Assert.assertEquals(lastName, contact.getLastName());
		//The phone number should reject using the JUnit test
		Assert.assertEquals(phoneNumber, contact.getPhoneNumber());
		Assert.assertEquals(address, contact.getAddress());
	}
	@Test
	public void testAddressLength() {
		String uniqueID = "BB1234";
		String firstName = "Nick";
		String lastName = "Askey";
		String phoneNumber = "8145055055";
		String address = "Uhh... the middle of nowhere? I am not really sure what to enter here for a good test";
		
		Contact contact = new Contact(uniqueID, firstName, lastName, phoneNumber, address);
		
		contactService.addContact(contact);
		
		Assert.assertEquals(uniqueID, contact.getUniqueID());
		Assert.assertEquals(firstName, contact.getFirstName());
		Assert.assertEquals(lastName, contact.getLastName());
		Assert.assertEquals(phoneNumber, contact.getPhoneNumber());
		//The address should reject using the JUnit test
		Assert.assertEquals(address, contact.getAddress());
	}
}
